package br.senai.controller;

public class FuncionarioController {
}
